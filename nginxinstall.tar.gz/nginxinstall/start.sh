#!/bin/bash

mkdir /usr/local/web
mkdir -p /usr/local/man/man1/
cp -rf nginxinstall/luajit2 /usr/local/web/
cp -rf nginxinstall/nginx /usr/local/
cp -rf nginxinstall/devopsNginx /root/
cp nginxinstall/nginx.service /usr/lib/systemd/system/
cp -rf nginxinstall/usr/lib64/lua /usr/lib64/
cp nginxinstall/usr/local/bin/* /usr/local/bin/
cp nginxinstall/usr/local/include/* /usr/local/include/
cp -rf nginxinstall/usr/local/lib/* /usr/local/lib/
cp nginxinstall/usr/local/man/man1/* /usr/local/man/man1/
cp -rf nginxinstall/usr/local/share/lua /usr/local/share/


systemctl enable nginx.service
