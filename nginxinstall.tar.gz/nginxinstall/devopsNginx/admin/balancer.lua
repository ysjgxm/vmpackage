local balancer = require "ngx.balancer"
local upstream = require "ngx.upstream"

local upstream_name = 'stable'
local srvs = upstream.get_servers(upstream_name)
ngx.say(srvs)
