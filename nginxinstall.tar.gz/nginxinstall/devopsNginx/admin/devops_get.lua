local dynupszone = ngx.shared.dyn_ups_zone
local ups = dynupszone:get("activeups");
if (ups == nil or ups == "") then
	return "stable"
else
	return ups
end


