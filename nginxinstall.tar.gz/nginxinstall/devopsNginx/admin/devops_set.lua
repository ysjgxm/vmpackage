local redis = require "resty.redis"

local switch_ups = ngx.req.get_uri_args()["activeups"]
if switch_ups == nil then 
    ngx.say("usage: /devops_switch?activeups=stable")  
    return "no activeups"
end

--创建实例
local redis_instance = redis:new()
--设置超时（毫秒）
redis_instance:set_timeout(3000)

--建立连接
local host = "127.0.0.1"
local port = 6379
local ok, err = redis_instance:connect(host, port)
if not ok then
	ngx.say("connect to redis error : ", err)
	return close_redis(redis_instance)
end

--选择库
local db,err = redis_instance:select(0);
if not db then
    ngx.say("failed to selectdb : ",err)
    return close_redis(redis_instance)
end

--Redis关闭
local function close_redis(redis_instance)
    if not redis_instance then
        return
    end
    local ok,err = redis_instance:close();
    if not ok then
        ngx.say("close redis error : ",err);
    end
end

local ok, err = redis_instance:set("activeups", switch_ups)
if not ok then
    ngx.say("failed to set activeups : ",switch_ups)
    return close_redis(redis_instance)
end
close_redis(redis_instance)

ngx.log(ngx.INFO, "active upstream server: ", switch_ups);
local dynupszone = ngx.shared.dyn_ups_zone;
local succ, err, forcible = dynupszone:set("activeups", switch_ups);
ngx.say("succ: ",succ, ", err: ", err, ", forcible: ", forcible);
ngx.say(dynupszone.get(dynupszone, "activeups"))
